<?php
$conn = mysqli_connect("localhost","root","","whitelist");
if(!$conn){
  die("Koneksi database gagal");
}
?>